var group__enemyHandler =
[
    [ "enemy_hit", "group__enemyHandler.html#ga6965d0b7bc93883e1089dd9a326a584a", null ],
    [ "move_enemy", "group__enemyHandler.html#ga95a06e0efaa583439b679f0b28419ba9", null ],
    [ "randomize_enemy_coordinates", "group__enemyHandler.html#gacc579aee4d796c717e760e72c1c75ec3", null ],
    [ "randomize_enemy_target_coordinates", "group__enemyHandler.html#ga778c7ea2e26eb1d80652bf61d1661fb1", null ],
    [ "randomize_enemy_type", "group__enemyHandler.html#ga21c57a411b6aa06a0f36c9eefab38b5b", null ]
];