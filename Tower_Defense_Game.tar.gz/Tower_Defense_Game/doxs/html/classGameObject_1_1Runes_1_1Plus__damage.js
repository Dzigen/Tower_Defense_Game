var classGameObject_1_1Runes_1_1Plus__damage =
[
    [ "Plus_damage", "classGameObject_1_1Runes_1_1Plus__damage.html#a9ed01c21040fda145bc262ca6c2d9822", null ],
    [ "addedDamage", "classGameObject_1_1Runes_1_1Plus__damage.html#a8d6f33861ad270c2f0c01abea24fd432", null ],
    [ "current_frame", "classGameObject_1_1Runes_1_1Plus__damage.html#a1993229d8a137d5dc6feb4b572a98bc0", null ],
    [ "frames", "classGameObject_1_1Runes_1_1Plus__damage.html#a09b7ecb5d9db3dad1942c5c3d08299f5", null ],
    [ "h", "classGameObject_1_1Runes_1_1Plus__damage.html#acb2903ce736dae31e937abbf7cb132b4", null ],
    [ "sprite", "classGameObject_1_1Runes_1_1Plus__damage.html#a1286be03fc1312928d408528f8bddf25", null ],
    [ "w", "classGameObject_1_1Runes_1_1Plus__damage.html#a67e0a90ac6bd68ecca36ef410c87a505", null ]
];