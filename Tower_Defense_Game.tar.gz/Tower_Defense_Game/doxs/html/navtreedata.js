var NAVTREE =
[
  [ "Игра \"Одинокая Турелька\"", "index.html", [
    [ "Требования к приложению", "index.html", null ],
    [ "Список задач", "todo.html", null ],
    [ "Группы", "modules.html", "modules" ],
    [ "Структуры данных", "annotated.html", [
      [ "Структуры данных", "annotated.html", "annotated_dup" ],
      [ "Алфавитный указатель структур данных", "classes.html", null ],
      [ "Поля структур", "functions.html", [
        [ "Указатель", "functions.html", "functions_dup" ],
        [ "Функции", "functions_func.html", null ],
        [ "Переменные", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Файлы", null, [
      [ "Файлы", "files.html", "files" ],
      [ "Список членов всех файлов", "globals.html", [
        [ "Указатель", "globals.html", null ],
        [ "Функции", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"functions_v.html"
];

var SYNCONMSG = 'нажмите на выключить для синхронизации панелей';
var SYNCOFFMSG = 'нажмите на включить для синхронизации панелей';