var move__enemy_8h =
[
    [ "randomize_enemy_coordinates", "group__enemyHandler.html#gacc579aee4d796c717e760e72c1c75ec3", null ],
    [ "randomize_enemy_target_coordinates", "group__enemyHandler.html#ga778c7ea2e26eb1d80652bf61d1661fb1", null ],
    [ "randomize_enemy_type", "group__enemyHandler.html#ga21c57a411b6aa06a0f36c9eefab38b5b", null ]
];