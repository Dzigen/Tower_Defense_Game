var group__runeHandler =
[
    [ "effect_of_the_rune", "group__runeHandler.html#ga0078b36ac662e224e1913996193c1c98", null ],
    [ "randomize_rune_coordinates", "group__runeHandler.html#gad3bb6254181bfa4913a3ec9a0f206f69", null ],
    [ "take_rune", "group__runeHandler.html#gaf2bb7b78f028e61a0c6674cd9b976a8c", null ],
    [ "update_spawn_rune", "group__runeHandler.html#ga813bbb2330c07f4bf303406c4efab35d", null ]
];