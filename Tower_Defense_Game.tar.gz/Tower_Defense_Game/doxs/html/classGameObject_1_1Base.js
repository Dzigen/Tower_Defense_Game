var classGameObject_1_1Base =
[
    [ "Base", "classGameObject_1_1Base.html#a31c0f6c9e600dacf73e76673b1a13c1e", null ],
    [ "base_roof", "classGameObject_1_1Base.html#a585759d198272b88275e6757d0cb9b2e", null ],
    [ "box_x", "classGameObject_1_1Base.html#a253d1b270383dde6a83bcced281df00e", null ],
    [ "box_y", "classGameObject_1_1Base.html#a6524bcc9f2c8581932f7bd474ddecc63", null ],
    [ "h", "classGameObject_1_1Base.html#afbfe39f23eea3c89426e1053ec1a064e", null ],
    [ "health", "classGameObject_1_1Base.html#aafab029af0a095c1b7751b94a630d5a8", null ],
    [ "live", "classGameObject_1_1Base.html#ad5b542f2b0694adbcdf26a088ab7394a", null ],
    [ "sprite", "classGameObject_1_1Base.html#ab8f40bafa7b9290ffa287df2b75eb49f", null ],
    [ "w", "classGameObject_1_1Base.html#ab8c68f4cc3270595be6867e2d0c4c8a4", null ]
];