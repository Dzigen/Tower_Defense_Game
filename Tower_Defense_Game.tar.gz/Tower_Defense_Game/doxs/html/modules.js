var modules =
[
    [ "Классы объектов", "group__objectClasses.html", "group__objectClasses" ],
    [ "Главные функции игрового цикла", "group__mainLoop.html", "group__mainLoop" ],
    [ "Отрисовка окон меню игры", "group__menu.html", "group__menu" ],
    [ "Обработчики главного героя и базы", "group__heroBaseHandler.html", "group__heroBaseHandler" ],
    [ "Обработчики противников", "group__enemyHandler.html", "group__enemyHandler" ],
    [ "Обработчики рун", "group__runeHandler.html", "group__runeHandler" ]
];