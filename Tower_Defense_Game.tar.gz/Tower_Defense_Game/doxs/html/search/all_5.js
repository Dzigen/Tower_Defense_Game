var searchData=
[
  ['flagtohold',['flagTOhold',['../classGameObject_1_1Enemys_1_1EnemyTemlate.html#a7e1e5fe7c3605c499e8ed688724dafc0',1,'GameObject::Enemys::EnemyTemlate']]],
  ['frame_5fh',['frame_h',['../classGameObject_1_1Enemys_1_1EnemyTemlate.html#a0d99581516d74d630535f1e4aff35938',1,'GameObject::Enemys::EnemyTemlate']]],
  ['frame_5fw',['frame_w',['../classGameObject_1_1Enemys_1_1EnemyTemlate.html#af58fe662ebf3cfd487d9863660c85956',1,'GameObject::Enemys::EnemyTemlate']]],
  ['frame_5fx',['frame_x',['../classGameObject_1_1Enemys_1_1EnemyTemlate.html#a4b48fcaa524fb492767f4de6ff10df91',1,'GameObject::Enemys::EnemyTemlate']]],
  ['frame_5fy',['frame_y',['../classGameObject_1_1Enemys_1_1EnemyTemlate.html#a675a141480e64ba5ba85ad8d5c61fd3c',1,'GameObject::Enemys::EnemyTemlate']]],
  ['frames',['frames',['../classGameObject_1_1Runes_1_1Hp__hero.html#a82d8e6e0510f203abe8b567722569b02',1,'GameObject::Runes::Hp_hero::frames()'],['../classGameObject_1_1Runes_1_1Hp__base.html#a6cd250a0e85ad0449365f33d452c6e28',1,'GameObject::Runes::Hp_base::frames()'],['../classGameObject_1_1Runes_1_1Plus__damage.html#a09b7ecb5d9db3dad1942c5c3d08299f5',1,'GameObject::Runes::Plus_damage::frames()'],['../classGameObject_1_1Runes_1_1Coin.html#a6caff0a83608e0ef628bcecae8114a07',1,'GameObject::Runes::Coin::frames()']]],
  ['framescomplited',['framesComplited',['../classGameObject_1_1Enemys_1_1EnemyTemlate.html#a3badead3c542bc494f789967e985f878',1,'GameObject::Enemys::EnemyTemlate']]]
];
