var searchData=
[
  ['plus_5fdamage',['Plus_damage',['../classGameObject_1_1Runes_1_1Plus__damage.html',1,'GameObject::Runes']]]
];
