var indexSectionsWithContent =
{
  0: "abcdefghilmprstuvwÐ",
  1: "bceghmprt",
  2: "bceghmprtu",
  3: "abceghilmprstu",
  4: "abcdefghilmprstvw",
  5: "Ð",
  6: "Ð"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Структуры данных",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Группы",
  6: "Страницы"
};

