var searchData=
[
  ['live',['live',['../classGameObject_1_1Base.html#ad5b542f2b0694adbcdf26a088ab7394a',1,'GameObject::Base::live()'],['../classGameObject_1_1Hero.html#af61f8b4ea25b9b12bebfd444bc125799',1,'GameObject::Hero::live()']]]
];
