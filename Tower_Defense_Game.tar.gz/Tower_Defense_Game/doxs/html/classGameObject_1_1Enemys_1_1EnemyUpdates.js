var classGameObject_1_1Enemys_1_1EnemyUpdates =
[
    [ "EnemyUpdates", "classGameObject_1_1Enemys_1_1EnemyUpdates.html#af2b1e03c8f6bac7594703e1a15040644", null ],
    [ "addedDamagePerRoundInPercentage", "classGameObject_1_1Enemys_1_1EnemyUpdates.html#ad0584b4ae2460f318204b9e221d781d4", null ],
    [ "addedHealthPerRoundInPercentage", "classGameObject_1_1Enemys_1_1EnemyUpdates.html#a7506081e1755536277fb8f388f57b395", null ],
    [ "enemySPAWNtime", "classGameObject_1_1Enemys_1_1EnemyUpdates.html#ae9de980bafa27f9cd53a3ed09ed1a1b2", null ],
    [ "h", "classGameObject_1_1Enemys_1_1EnemyUpdates.html#acfe6d4eef800ac30a8ae7b5f42b8553c", null ],
    [ "w", "classGameObject_1_1Enemys_1_1EnemyUpdates.html#a02597f023815942af2e28ed6a3bf0c74", null ]
];