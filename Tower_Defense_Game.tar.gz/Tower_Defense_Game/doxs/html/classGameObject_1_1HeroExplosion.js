var classGameObject_1_1HeroExplosion =
[
    [ "HeroExplosion", "classGameObject_1_1HeroExplosion.html#a6bbe6fd284863bcf70b0e4447d8f46c1", null ],
    [ "updateFrame", "classGameObject_1_1HeroExplosion.html#ac5fa2bfc1bdd8179ad5f113d81e19252", null ],
    [ "colomn", "classGameObject_1_1HeroExplosion.html#a9484619a70aa340b7960984067053225", null ],
    [ "h", "classGameObject_1_1HeroExplosion.html#a3934725c63657743d0ee6d08030a36a1", null ],
    [ "sprite", "classGameObject_1_1HeroExplosion.html#a6d55438bf1ecf9ced768fa677ebe646d", null ],
    [ "w", "classGameObject_1_1HeroExplosion.html#afdb47a4793449f3f75d657535ea6be2c", null ]
];