var classGameEndWindow =
[
    [ "GameEndWindow", "classGameEndWindow.html#a47971f54545bcf39783852568ccf90ab", null ],
    [ "check_timer", "classGameEndWindow.html#a00ec6d032219c692a678b7ddac55a3b3", null ],
    [ "setDescription", "classGameEndWindow.html#a2f5dcaf5df932f64323d14f58b5649e6", null ],
    [ "update_timer", "classGameEndWindow.html#a91d7d99ae0dac923a1bf764f7b5d996f", null ],
    [ "description", "classGameEndWindow.html#ab29a8ae98c80ff3facba1c9f58f57ed1", null ],
    [ "h", "classGameEndWindow.html#adf2232ddacea4f327e8b1315633f4e4b", null ],
    [ "secondsTillExit", "classGameEndWindow.html#a7705716c485ae134468ec5cc3e92812d", null ],
    [ "sprite", "classGameEndWindow.html#ae1cfd12474c38f65885885c05d3f45da", null ],
    [ "timer", "classGameEndWindow.html#a2cda6ea6738d35480ca4ede7fd494fa9", null ],
    [ "w", "classGameEndWindow.html#aec3d8eedb5288ddb2a218d8e2eb0a3b1", null ]
];